'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import AnalysisPage from './analysis/stocks/page' // ✅ import trang phân tích AI

export default function HomePage() {
  const [userName, setUserName] = useState('')
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analysis'>('dashboard') // 🔄 rename "invest" → "analysis"

  const router = useRouter()

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session }, error } = await supabase.auth.getSession()
      if (error || !session) {
        router.push('/login')
        return
      }
      const user = session.user
      const name = user.user_metadata?.full_name || user.email
      setUserName(name)
      setLoading(false)
      router.refresh()
    }
    fetchUser()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-white">
        <h2 className="animate-pulse text-xl font-semibold">⏳ Đang tải dữ liệu...</h2>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold mb-6 text-purple-300">Xin chào, {userName}</h1>

      <div className="flex gap-3 flex-wrap mb-4">
        {[
          { key: 'dashboard', label: '📊 Dashboard' },
          { key: 'analysis', label: '📈 Đầu tư' }, // ✅ rename tab
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-4 py-2 rounded-md text-sm font-medium border ${
              activeTab === tab.key
                ? 'bg-indigo-600 text-white'
                : 'text-slate-200 hover:bg-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'dashboard' && (
        <section>
          <h2 className="text-xl font-bold text-teal-300 mb-2">📊 Tổng quan tài chính</h2>
          <p>Hiển thị số dư, tổng đầu tư, tổng chi tiêu, và các biểu đồ tóm tắt.</p>
        </section>
      )}

      {activeTab === 'analysis' && (
        <section className="mt-4">
          <AnalysisPage /> {/* ✅ chèn trang phân tích AI */}
        </section>
      )}
    </div>
  )
}
